function execute(url, page) {
    return Response.success([
        {
            name: "Kẻ vô lại nhà Bá tước",
            link: "https://littlethingbutspecial.wordpress.com/ke-vo-lai-cua-nha-ba-tuoc",
            cover: "https://littlethingbutspecial.files.wordpress.com/2023/09/volai.png?w=702",
            host: "https://littlethingbutspecial.wordpress.com",
            description: "",
        },
    ]);
}
