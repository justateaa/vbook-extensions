function execute() {
    return Response.success([{ title: "Home", input: "/ke-vo-lai-cua-nha-ba-tuoc", script: "gen.js" }]);
}
