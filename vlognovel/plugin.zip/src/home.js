function execute() {
    return Response.success([
        { title: "Hot", input: "https://vlognovelpro.com/the-loai/dang-hot", script: "gen.js" },
        { title: "Mới Nhất", input: "https://vlognovelpro.com/the-loai/moi-cap-nhap", script: "gen.js" },
        { title: "Xem nhiều", input: "https://vlognovelpro.com/de-nghi/pho-bien/xem-nhieu", script: "gen.js" },
    ]);
}
